#include "tuya_cloud_types.h"
#include "tuya_cloud_error_code.h"
#include "tuya_cloud_com_defs.h"
#include "tuya_iot_com_api.h"
#include "uni_log.h"

#include "tuya_cloud_base_defs.h"
#include "tuya_iot_base_api.h"

#include <stdio.h>
#include <unistd.h>
#include <string.h>

#include "tuya_pegasus.h"
#include "prr.h"

STATIC BYTE_T s_tuya_oui[3] = {0x0};

#define LOG_LEN_MAX 1024
VOID print_buf(BYTE_T *in, UINT_T len, CHAR_T *name)
{
    UINT_T i = 0, offset = 0;
    CHAR_T buffer[LOG_LEN_MAX * 2 + 1] = {0};

    if (NULL == in || NULL == name) {
        return;
    }

    if (len > LOG_LEN_MAX) {
        PR_ERR("%s(len:%u) too long", name, len);
        return;
    }
    
    snprintf(buffer, sizeof(buffer), "%s(len:%u): ", name, len);
    offset = strlen(buffer);
    for (i = 0; i < len; i++) {
        snprintf(buffer + offset, sizeof(buffer) - offset, "%02x", in[i]);
        offset += 2;
    }
        
    PR_DEBUG(buffer);
}

VOID ty_pegasus_event_cb(IN CONST TY_PEGASUS_EVENT_E event)
{
    PR_DEBUG("pegasus event %d", event);
    if (TY_PEGASUS_GET_PROBE_START == event) {

        INT_T idx = 0;
        UCHAR_T mac[6] = {0x0};
        CHAR_T devid[16 + 1] = {0x0};
        UCHAR_T zmc[6] = {0};
        UCHAR_T vsieRxBuf[260];
        for (idx = 0; idx >= 0;) {
            memset(devid, 0x0, sizeof(devid));
            memset(mac, 0x0, sizeof(mac));
            memset(vsieRxBuf, 0x0, sizeof(vsieRxBuf));
            PR_DEBUG("prr_dev_get start...");
            idx = prr_dev_get(idx, mac, devid, vsieRxBuf, sizeof(vsieRxBuf));
            PR_DEBUG("result idx:%d", idx);
            if (idx >= 0) {
                PR_DEBUG("mac %s,device id:%s\n", mac2str(mac), devid);
                // printfdata("vsie:", vsieRxBuf, vsieRxBuf[1] + 2);
                if (!memcmp(mac, zmc, sizeof(mac))) {
                    PR_INFO("mac NULL");        
                    break;
                }

                print_buf(vsieRxBuf, vsieRxBuf[1] + 2, "rx vsie");
                NW_MAC_S smac;
                memcpy(smac.mac, mac, sizeof(mac));
                tuya_pegasus_rept_probe(vsieRxBuf + 2, vsieRxBuf[1], &smac, NULL);
                if (idx == 0) {
                    PR_INFO("no more vsie device");   
                    break;
                }

            } else {
                PR_INFO("no vsie device found");
                break;
            }
        }
    } else if (TY_PEGASUS_START == event) {
        if (prr_link_set(1, s_tuya_oui) < 0) {
            PR_DEBUG("prr enable fail");
        } else {
            PR_DEBUG("prr enable success");
        }
    } else if (TY_PEGASUS_STOP == event) {
        if (prr_link_set(0, s_tuya_oui) < 0) {
            PR_DEBUG("prr enable fail");
        } else {
            PR_DEBUG("prr enable success");
        }
    }
}

OPERATE_RET ty_pegasus_send_frame_cb(IN CONST TY_FRAME_TYPE_E type, IN CONST UINT8_T *vsie, 
                                     IN CONST UINT_T vsie_len, IN NW_MAC_S *srcmac, IN NW_MAC_S *dstmac)
{
    PR_DEBUG("pegasus send frame type %d", type);
    print_buf(vsie, vsie_len, "tx vsie");
    vsie_frame_type_e frame_type = (TY_FRAME_TP_BEACON == type) ? VSIE_FRAME_TYPE_BEACON : VSIE_FRAME_TYPE_PROBERSP;
    int ret = prr_tx_data(frame_type, vsie, vsie_len);
    if (0 != ret) {
        PR_ERR("prr_tx_data error ret:%d", ret);
        return ret;
    }

    PR_DEBUG("prr_tx_data type:%d len:%d", frame_type, vsie_len);
    return OPRT_OK;
}

static void flash_get_info(const char *cmd, char *result, int size)
{
    char buf[128] = {0};

    FILE *fp = popen(cmd, "r");
    if (fp == NULL)
        return ;
    fread(buf, sizeof(char), sizeof(buf), fp);
    pclose(fp);
    int len = strlen(buf);
    if(len  > 1 || '\n' == result[len -1]) {
        buf[len  - 1] = '\0';
    }
    snprintf(result, size, "%s", buf);
}

OPERATE_RET ty_pegasus_get_ssid_pwd_cb(OUT UINT8_T *ssid, IN INT_T slen, OUT UINT8_T *pwd, IN INT_T plen)
{
    PR_DEBUG("pegasus get ssid pwd");
    prr_wifi_cfg_t pwc = {0x0};

#if 0
    int ret = prr_wifi_get_cfg(&pwc);
    if (ret != 0) {
        PR_ERR("get wifi cfg error: %d", ret);
        return OPRT_COM_ERROR;
    }
#else
    flash_get_info("flash get WLAN1_WSC_SSID", pwc.ssid, sizeof(pwc.ssid));
    flash_get_info("flash get WLAN1_WSC_PSK", pwc.pwd, sizeof(pwc.pwd));
#endif
    snprintf(ssid, slen, "%s", pwc.ssid);
    snprintf(pwd, plen, "%s", pwc.pwd);

    PR_DEBUG("ssid[%s], passwd[%s]", ssid, pwd);

    return OPRT_OK;
}

//#define WLAN_DEV            "wlan0"
#define WLAN_DEV            "wlan1"
#define WF_MAC_ETHER_STR    "HWaddr "
OPERATE_RET ty_pegasus_get_mac_cb(OUT NW_MAC_S *mac)
{
    FILE *pp = popen("ifconfig "WLAN_DEV, "r");
    if(pp == NULL) {
        return OPRT_COM_ERROR;
    }

    char tmp[256];
    memset(tmp, 0, sizeof(tmp));
    while (fgets(tmp, sizeof(tmp), pp) != NULL)
    {
        char *pMACStart = strstr(tmp, WF_MAC_ETHER_STR);
        if(pMACStart != NULL) {
            int x1,x2,x3,x4,x5,x6;
            sscanf(pMACStart + strlen(WF_MAC_ETHER_STR), "%x:%x:%x:%x:%x:%x",&x1,&x2,&x3,&x4,&x5,&x6);
            mac->mac[0] = x1 & 0xFF;
            mac->mac[1] = x2 & 0xFF;
            mac->mac[2] = x3 & 0xFF;
            mac->mac[3] = x4 & 0xFF;
            mac->mac[4] = x5 & 0xFF;
            mac->mac[5] = x6 & 0xFF;
            break;
        }
    }
    pclose(pp);
    PR_DEBUG("Get MAC %02X-%02X-%02X-%02X-%02X-%02X", mac->mac[0],mac->mac[1],mac->mac[2],mac->mac[3],mac->mac[4],mac->mac[5]);
    return OPRT_OK;
}

OPERATE_RET ty_pegasus_set_oui_cb(IN BYTE_T *oui, IN BYTE_T oui_len)
{
    memcpy(s_tuya_oui, oui, oui_len);
}

OPERATE_RET tuya_pegasus_test_start()
{
    TUYA_PEGASUS_CBS_S cbs = {
        ty_pegasus_event_cb,
        ty_pegasus_send_frame_cb,
        ty_pegasus_get_ssid_pwd_cb,
        ty_pegasus_get_mac_cb,
        ty_pegasus_set_oui_cb
    };
    
    return tuya_hal_pegasus_init(&cbs, 0);
}