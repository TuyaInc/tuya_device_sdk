rm -rf output
./build_app.sh demos/ ty_gw_smart_router_cyx 1.5


1、修改历史
--细化DP点功能
--修改成公版DP

