#include "tuya_cloud_types.h"
#include "tuya_cloud_error_code.h"
#include "tuya_cloud_com_defs.h"
#include "tuya_iot_com_api.h"
#include "uni_log.h"

#include "tuya_cloud_base_defs.h"
#include "tuya_iot_base_api.h"

#include <stdio.h>
#include <unistd.h>
#include <string.h>

#include "tuya_pegasus.h"

STATIC BYTE_T s_tuya_oui[3] = {0x0};

#define LOG_LEN_MAX 1024
VOID print_buf(BYTE_T *in, UINT_T len, CHAR_T *name)
{
    UINT_T i = 0, offset = 0;
    CHAR_T buffer[LOG_LEN_MAX * 2 + 1] = {0};

    if (NULL == in || NULL == name) {
        return;
    }

    if (len > LOG_LEN_MAX) {
        PR_ERR("%s(len:%u) too long", name, len);
        return;
    }
    
    snprintf(buffer, sizeof(buffer), "%s(len:%u): ", name, len);
    offset = strlen(buffer);
    for (i = 0; i < len; i++) {
        snprintf(buffer + offset, sizeof(buffer) - offset, "%02x", in[i]);
        offset += 2;
    }
        
    PR_DEBUG(buffer);
}

VOID ty_pegasus_event_cb(IN CONST TY_PEGASUS_EVENT_E event)
{
    PR_TRACE("pegasus event %d", event);
    if (TY_PEGASUS_GET_PROBE_START == event) {

    } else if (TY_PEGASUS_START == event) {

    } else if (TY_PEGASUS_STOP_DICOVERY == event) {

    } else if (TY_PEGASUS_STOP == event) {

    }
}

OPERATE_RET ty_pegasus_send_frame_cb(IN CONST TY_FRAME_TYPE_E type, IN CONST UINT8_T *vsie, 
                                     IN CONST UINT_T vsie_len, IN NW_MAC_S *srcmac, IN NW_MAC_S *dstmac)
{
    int ret = 0;

    PR_DEBUG("pegasus send frame type %d", type);
    //print_buf(vsie, vsie_len, "tx vsie");

    if (TY_FRAME_TP_BEACON == type) {

    } else {

    }

    return OPRT_OK;
}

static void flash_get_info(const char *cmd, char *result, int size)
{
    char buf[128] = {0};

    FILE *fp = popen(cmd, "r");
    if (fp == NULL)
        return ;
    fread(buf, sizeof(char), sizeof(buf), fp);
    pclose(fp);
    int len = strlen(buf);
    if(len  > 1 || '\n' == result[len -1]) {
        buf[len  - 1] = '\0';
    }
    snprintf(result, size, "%s", buf);
}

OPERATE_RET ty_pegasus_get_ssid_pwd_cb(OUT UINT8_T *ssid, IN INT_T slen, OUT UINT8_T *pwd, IN INT_T plen)
{
    PR_DEBUG("pegasus get ssid pwd");

    snprintf(ssid, slen, "%s", "netcore2.4G");
    snprintf(pwd, plen, "%s", "Net#9ka2");

    PR_DEBUG("ssid[%s], passwd[%s]", ssid, pwd);

    return OPRT_OK;
}

//#define WLAN_DEV            "wlan0"
#define WLAN_DEV            "wlan1"
#define WF_MAC_ETHER_STR    "HWaddr "
OPERATE_RET ty_pegasus_get_mac_cb(OUT NW_MAC_S *mac)
{
    FILE *pp = popen("ifconfig "WLAN_DEV, "r");
    if(pp == NULL) {
        return OPRT_COM_ERROR;
    }

    char tmp[256];
    memset(tmp, 0, sizeof(tmp));
    while (fgets(tmp, sizeof(tmp), pp) != NULL)
    {
        char *pMACStart = strstr(tmp, WF_MAC_ETHER_STR);
        if(pMACStart != NULL) {
            int x1,x2,x3,x4,x5,x6;
            sscanf(pMACStart + strlen(WF_MAC_ETHER_STR), "%x:%x:%x:%x:%x:%x",&x1,&x2,&x3,&x4,&x5,&x6);
            mac->mac[0] = x1 & 0xFF;
            mac->mac[1] = x2 & 0xFF;
            mac->mac[2] = x3 & 0xFF;
            mac->mac[3] = x4 & 0xFF;
            mac->mac[4] = x5 & 0xFF;
            mac->mac[5] = x6 & 0xFF;
            break;
        }
    }
    pclose(pp);
    PR_DEBUG("Get MAC %02X-%02X-%02X-%02X-%02X-%02X", mac->mac[0],mac->mac[1],mac->mac[2],mac->mac[3],mac->mac[4],mac->mac[5]);
    return OPRT_OK;
}

OPERATE_RET ty_pegasus_set_oui_cb(IN BYTE_T *oui, IN BYTE_T oui_len)
{
    memcpy(s_tuya_oui, oui, oui_len);
}

OPERATE_RET tuya_pegasus_test_start()
{
    TUYA_PEGASUS_CBS_S cbs = {
        ty_pegasus_event_cb,
        ty_pegasus_send_frame_cb,
        ty_pegasus_get_ssid_pwd_cb,
        ty_pegasus_get_mac_cb,
        ty_pegasus_set_oui_cb
    };

    return tuya_pegasus_service_init(&cbs, 0);
}