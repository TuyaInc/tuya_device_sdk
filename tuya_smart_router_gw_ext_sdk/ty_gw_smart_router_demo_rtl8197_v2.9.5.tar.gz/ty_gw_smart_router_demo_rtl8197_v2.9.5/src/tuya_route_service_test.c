#include "tuya_cloud_types.h"
#include "tuya_cloud_error_code.h"
#include "tuya_cloud_com_defs.h"
#include "tuya_iot_com_api.h"
#include "uni_log.h"

#include "tuya_cloud_base_defs.h"
#include "tuya_iot_base_api.h"

#include <stdio.h>
#include <unistd.h>
#include <string.h>

#include "tuya_svc_route.h"

BOOL_T route_allow = 1; 
BOOL_T route_limit = 1;
UINT_T route_up_limit = 10;
UINT_T route_down_limit = 20;

#define STA_DPID (15)//115

VOID ty_route_sta_cmd_cb(IN CONST TY_ROUTE_STA_CMD_E cmd, IN CONST CHAR_T *mac, 
                                    IN CONST UINT_T value)
{
    TUYA_ROUTE_STA_CONF_S config = {0x0};

    PR_DEBUG("cmd:%d mac:%s value:%d\n", cmd, mac, value);
    switch (cmd) {
        case TY_STA_CMD_ALLOW_NET:     
            route_allow = value;
            tuya_route_rept_sta_allow_net(mac, route_allow, STA_DPID);
            break;

        case TY_STA_CMD_SPEED_LIMIT:     
            route_limit = value;
            tuya_route_rept_sta_limit(mac, route_limit, STA_DPID);
            break;

        case TY_STA_CMD_UP_LIMIT:     
            route_up_limit = value;
            tuya_route_rept_sta_up_limit(mac, route_up_limit, STA_DPID);
            break;

        case TY_STA_CMD_DOWN_LIMIT:     
            route_down_limit = value;
            tuya_route_rept_sta_down_limit(mac, route_down_limit, STA_DPID);
            break;

        case TY_STA_CMD_GET_ALL_CONFIG:     
            config.allow = route_allow;
            config.limit = route_limit;
            config.up_limit = route_up_limit;
            config.down_limit = route_down_limit;
            tuya_route_rept_sta_all(mac, &config, STA_DPID);
            break;

        default:
            break;

    }
}

VOID ty_route_cmd_cb(IN CONST TY_ROUTE_CMD_E cmd)
{
    TUYA_ROUTE_DEV_LIST_S list[2] = {0x0};
    strcpy(list[0].dev_name, "iphone");
    strcpy(list[0].mac, "11:22:33:44:55:66");
    strcpy(list[1].dev_name, "iphone2");
    strcpy(list[1].mac, "77:22:33:44:55:66");
    tuya_route_rept_online_list(2, list);
}

STATIC CHAR_T route_pwd[2][20] = {"123456", "abcdef"};
VOID ty_route_query_pwd_cb(IN CONST TUYA_ROUTE_PWD_E type)
{
    if (TY_ROUTE_PWD_INVALID == type ) {
        PR_ERR("invalid param");
        return ;
    }
    INT_T i = (INT_T)type - 1;
    PR_DEBUG("type:%d, pwd:%s", (INT_T)type, route_pwd[i]);
    tuya_route_rept_pwd(type, route_pwd[i]);
    //有iot设备接入路由，修改wifi用户名或密码后，需要开启二次配网
    //pegasus_server_second_start(10 * 60);
}

VOID ty_route_set_pwd_cb(IN CONST TUYA_ROUTE_PWD_E type, IN CONST CHAR_T *pwd)
{
    if (TY_ROUTE_PWD_INVALID == type ) {
        PR_ERR("invalid param");
        return ;
    }
    INT_T i = (INT_T)type - 1;
    PR_DEBUG("type:%d, pwd:%s", (INT_T)type, pwd);
    snprintf(route_pwd[i], sizeof(route_pwd[i]), "%s", pwd);
    ty_route_query_pwd_cb(type);
}

OPERATE_RET tuya_route_test_start(VOID)
{
    OPERATE_RET op_ret = OPRT_OK;
    TUYA_ROUTE_CBS_S route_cbs = {
        ty_route_cmd_cb,
        ty_route_query_pwd_cb,
        ty_route_set_pwd_cb
    };

    TUYA_ROUTE_STA_CBS_S sta_cbs = {
        ty_route_sta_cmd_cb
    };

    op_ret = tuya_route_service_init(&route_cbs, &sta_cbs);
    if (op_ret != OPRT_OK) {
        PR_ERR("tuya_route_service_init faild, [%d]", op_ret);
    }

    sleep(1);
    TUYA_ROUTE_DEV_LIST_S list[2] = {0x0};
    strcpy(list[0].dev_name, "iphone");
    strcpy(list[0].mac, "11:22:33:44:55:66");
    strcpy(list[1].dev_name, "iphone2");
    strcpy(list[1].mac, "77:22:33:44:55:66");
    op_ret = tuya_route_rept_online_list(2, list);
    if (op_ret != OPRT_OK) {
        PR_ERR("tuya_route_rept_online_list faild, [%d]", op_ret);
    }

    op_ret = tuya_route_rept_pwd(TY_ROUTE_PWD_2_4G, "123456");
    if (op_ret != OPRT_OK) {
        PR_ERR("tuya_route_rept_pwd faild, [%d]", op_ret);
    }
    op_ret = tuya_route_rept_sta_allow_net("11:22:33:44:55:66", 1, STA_DPID);
    if (op_ret != OPRT_OK) {
        PR_ERR("tuya_route_rept_sta_allow_net faild, [%d]", op_ret);
    }
    op_ret = tuya_route_rept_sta_up_limit("11:22:33:44:55:66", 100, STA_DPID);
    if (op_ret != OPRT_OK) {
        PR_ERR("tuya_route_rept_sta_up_limit faild, [%d]", op_ret);
    }

    TUYA_ROUTE_STA_CONF_S config = {0x0};
    config.allow = route_allow;
    config.limit = route_limit;
    config.up_limit = route_up_limit;
    config.down_limit = route_down_limit;
    op_ret = tuya_route_rept_sta_all("11:22:33:44:55:66", &config, STA_DPID);
    if (op_ret != OPRT_OK) {
        PR_ERR("tuya_route_rept_sta_all faild, [%d]", op_ret);
    }

    op_ret = tuya_route_sta_data_parse("{\"mac\":\"11:22:33:44:55:66\",\"maxUpSpeed\":10}");
    if (op_ret != OPRT_OK) {
        PR_ERR("tuya_route_sta_data_parse faild, [%d]", op_ret);
    }

    return OPRT_OK;
}