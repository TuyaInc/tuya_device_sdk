/*
tuya_zigbee_service.h
Copyright(C),2018-2020, 涂鸦科技 www.tuya.comm
*/

#ifndef TUYA_ZIGBEE_SERVICE_H
#define TUYA_ZIGBEE_SERVICE_H

#ifdef __cplusplus
extern "C" {
#endif

#ifdef TUYA_ZIGBEE_ENABLE    
#include "tuya_z3.h"
#include "tuya_z3_api_tmp.h"
//#include "tuya_module_test.h"
#include "tuya_encrypt.h"
#include "rex_lock_encrypt.h"
#include "tuya_reliable.h"
#include "tuya_z3_base.h"
#include "tuya_app_plateform_cfg.h"
//#include "tuya_app_hal.h"
#include "user_log.h"
#include "tuya_z3_host_storage.h"
#include "tuya_z3_intf.h"
#include "tuya_z3_upgrade.h"
#endif    

// 网关内部通讯模块固件版本，用于OTA管理，格式必须为"XX.XX.XX"，其中XX必须为数字
#define USER_DEV_IN_GW_SW_VER "1.0.0"

#define TUYA_ZIGBEE_CONF_PATH       "/var/tuya/cfg/def.cfg"

typedef VOID (* TY_ZB_CHILD_PROC_EXIT_CB)(VOID);

typedef struct {
    TY_ZB_CHILD_PROC_EXIT_CB    child_proc_exit_cb;
} TY_ZB_PROC_MNG_CB_S;

typedef TY_CMD_U TY_SPEAKER_CMD_U;

typedef enum {
    OBJ_CMD = 0,
    RAW_CMD,
}TY_CMD_TYPE;

OPERATE_RET tuya_zigbee_down_process(IN CHAR_T *dev_id,IN TY_SPEAKER_CMD_U *cmd, IN TY_CMD_TYPE cmd_type);
OPERATE_RET tuya_zigbee_dp_query(IN        TY_DP_QUERY_S *dp_qry);
VOID tuya_gw_ug_inform(IN CONST FW_UG_S *fw);
OPERATE_RET tuya_dev_ug_inform(IN CONST CHAR_T *dev_id,IN CONST FW_UG_S *fw);
VOID tuya_dev_reset(IN CONST CHAR_T *dev_id,IN DEV_RESET_TYPE_E type);
#if defined(TUYA_GW_OPERATOR) && (TUYA_GW_OPERATOR==1)        
OPERATE_RET tuya_dev_ope_httpc_get_chcode(IN CONST BOOL_T is_gw, IN CONST CHAR_T *devid, INOUT CH_CODE_ST *ch_code);
#endif
BOOL_T tuya_gw_add_dev(IN CONST GW_PERMIT_DEV_TP_T tp,IN CONST BOOL_T permit,IN CONST UINT_T timeout);
VOID tuya_gw_del(IN CONST CHAR_T *dev_id);
OPERATE_RET tuya_gw_grp_process(IN CONST GRP_ACTION_E action,IN CONST CHAR_T *dev_id,IN CONST CHAR_T *grp_id);
OPERATE_RET tuya_gw_scene_process(IN CONST SCE_ACTION_E action,IN CONST CHAR_T *dev_id,\
                                            IN CONST CHAR_T *grp_id,IN CONST CHAR_T *sce_id);
VOID tuya_dev_bind_ifm(IN CONST CHAR_T *dev_id,IN CONST OPERATE_RET op_ret);
OPERATE_RET tuya_get_zigbee_ver(GW_ATTACH_ATTR_T *p_attr);
VOID tuya_zigbee_intf_wf_nw_status(IN CONST GW_WIFI_NW_STAT_E stat);
VOID tuya_zigbee_intf_base_nw_status(IN CONST GW_BASE_NW_STAT_T stat);
VOID tuya_zigbee_get_spec_log();

VOID tuya_gw_data_reset(VOID);
OPERATE_RET tuya_gw_zigbee_server_init(GW_ATTACH_ATTR_T *p_attr);
OPERATE_RET tuya_gw_zigbee_service_start(VOID);

#ifdef __cplusplus
}
#endif
#endif
