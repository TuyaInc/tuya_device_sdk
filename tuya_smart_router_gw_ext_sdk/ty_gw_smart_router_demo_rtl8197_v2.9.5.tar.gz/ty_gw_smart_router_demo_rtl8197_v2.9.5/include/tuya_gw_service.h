#ifndef TUYA_GW_SERVICE_H
#define TUYA_GW_SERVICE_H

#include "tuya_iot_com_api.h"
#include "tuya_cloud_base_defs.h"
#include "tuya_iot_base_api.h"
#include "uni_network.h"

#ifdef __cplusplus
extern "C" {
#endif

#define TY_INFO(...)        do{\
                                fprintf(stderr, "[INFO] [%s:%d]",__func__,__LINE__);\
                                fprintf(stderr, __VA_ARGS__);\
                            }while(0)  
#define TY_ERR(...)         do{\
                                fprintf(stderr, "[ERR] [%s:%d]",__func__,__LINE__);\
                                fprintf(stderr, __VA_ARGS__);\
                            }while(0)  
#define TY_CRIT(...)        do{\
                                fprintf(stderr, "[CRIT] [%s:%d]",__func__,__LINE__);\
                                fprintf(stderr, __VA_ARGS__);\
                            }while(0)   

#ifndef STR_LEN_MAX32
#define STR_LEN_MAX32  32
#endif

#ifndef STR_LEN_MAX64
#define STR_LEN_MAX64  64
#endif

#ifdef __ANDROID__
#define STR_LEN_MAX     STR_LEN_MAX64
#else
#define STR_LEN_MAX     STR_LEN_MAX32
#endif

typedef enum {
    TUYA_IOT_STAT_UNCONN = 0,
    TUYA_IOT_STAT_CLOUD_CONN = 1,
    
} TUYA_IOT_NET_STAT_E;

typedef VOID (*TUYA_GW_STAT_CHANGED_CB)(IN CONST GW_STATUS_E status);
typedef VOID (*TUYA_GW_UG_INFORM_CB)(IN CONST FW_UG_S *fw);
typedef VOID (*TUYA_GW_RESET_IFM_CB)(GW_RESET_TYPE_E type);
typedef VOID (*TUYA_GW_REBOOT_CB)(VOID);
typedef VOID (*TUYA_GW_OBJ_DP_CMD_CB)(IN CONST TY_RECV_OBJ_DP_S *dp);
typedef VOID (*TUYA_GW_RAW_DP_CMD_CB)(IN CONST TY_RECV_RAW_DP_S *dp);
typedef VOID (*TUYA_GW_DP_QUERY_CB)(IN CONST TY_DP_QUERY_S *dp_qry);
//typedef VOID (*TUYA_GW_NW_STAT_CB)(IN CONST TUYA_IOT_NET_STAT_E stat);
typedef VOID (*TUYA_GW_NW_STAT_CB)(IN CONST GW_BASE_NW_STAT_T stat);
typedef VOID (*TUYA_GW_GET_LOG_FILE_CB)(OUT CHAR_T *file_name, IN CONST INT_T len);
typedef OPERATE_RET (*TUYA_GW_GET_SM_INFO_CB)(CHAR_T *ssid, UINT_T ssid_size, CHAR_T *key, UINT_T key_size);
typedef VOID (*TUYA_GW_CPROC_EXIT_CB)(VOID);


#ifdef TUYA_ZIGBEE_ENABLE
typedef struct{
    CHAR_T serial_port[STR_LEN_MAX+1];    //zigbee串口设备号
    BOOL_T is_cts;                          //是否带有流控

    CHAR_T tmp_dir[STR_LEN_MAX+1];        //临时文件目录
    CHAR_T bin_dir[STR_LEN_MAX+1];        //bin文件目录，勿存放文件，其他平台可能为只读文件系统
    CHAR_T log_dir[STR_LEN_MAX+1];        //日志存储目录

} TUYA_ZB_CONFIG_S;
#endif

typedef struct {    
    CHAR_T storage_path[STR_LEN_MAX+1];
    CHAR_T product_key[STR_LEN_MAX+1];
    CHAR_T uuid[STR_LEN_MAX+1];
    CHAR_T auth_key[STR_LEN_MAX+1];
    CHAR_T sw_ver[STR_LEN_MAX+1];
    BOOL_T is_oem;

    TUYA_GW_STAT_CHANGED_CB gw_stat_changed_cb;
    TUYA_GW_UG_INFORM_CB    gw_ug_inform_cb;
    TUYA_GW_RESET_IFM_CB    gw_reset_cb;
    TUYA_GW_REBOOT_CB       gw_reboot_cb;
    TUYA_GW_OBJ_DP_CMD_CB   obj_dp_cmd_cb;
    TUYA_GW_RAW_DP_CMD_CB   raw_dp_cmd_cb;
    TUYA_GW_DP_QUERY_CB     dp_query_cb;
    TUYA_GW_NW_STAT_CB      nw_stat_cb;
    TUYA_GW_GET_LOG_FILE_CB get_log_file;
    TUYA_GW_GET_SM_INFO_CB  get_sm_info_cb;

#ifdef TUYA_ZIGBEE_ENABLE    
    TUYA_ZB_CONFIG_S        zb_config;
    TUYA_GW_CPROC_EXIT_CB   child_proc_exit_cb;
#endif    
} TUYA_GW_ENV_S;

OPERATE_RET tuya_gw_get_zigbee_ver(CHAR_T *p_ver, UINT_T in_len);
OPERATE_RET tuya_gw_zigbee_rf_test(UINT_T channel, UINT_T number);
USHORT_T tuya_get_zigbee_rf_test_result();

OPERATE_RET tuya_gw_service_start(TUYA_GW_ENV_S *p_env);
OPERATE_RET tuya_gw_service_reset(VOID);

OPERATE_RET tuya_local_add_dev_start(UINT_T timeout);
OPERATE_RET tuya_local_add_dev_stop(VOID);


#ifdef __cplusplus
}
#endif

#endif
